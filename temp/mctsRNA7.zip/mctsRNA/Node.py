import math
import yaml
from random import choice, shuffle

class TreeNode():
    configs = yaml.load(open("config.yml", "r"), Loader=yaml.FullLoader)
    def __init__(self, state, action_ix, to_here=None,
                 parent=None, prior=True):
        self.state = state
        self.parent = parent
        self.action_ix = action_ix
        self.children = {}
        self.visits = 1
        self.total_value = 0.
        self.to_here = to_here
        # bias of prior base distribution
        self.prior = self.get_prior(to_here) if prior else 1
        self.is_expanded = False
        self.is_terminal = self.state.is_terminal()
        shuffle(self.configs["paired"])
        shuffle(self.configs["unpaired"])
        self.C = math.sqrt(2)

    def get_prior(self, to_here):  # prior base distribution
        if self.to_here is None:
            return 1
        #print(f"paired {self.configs['paired_prob']} unpaired {self.configs['unpaired_prob']} action {to_here}")
        prior = self.configs["paired_prob"][to_here] if self.to_here in self.configs[
            "paired"] else self.configs["unpaired_prob"][to_here]
        return prior

    def Q(self) -> float:  # q function
        return self.total_value / self.visits

    def U(self) -> float:  # explore
        return self.C * self.prior * \
            math.sqrt(2.0 * math.log(self.parent.visits) / self.visits)

    def best_child(self, infer=False):  # UCB formula
        if infer:
            return max(self.children.values(), key=lambda node: node.Q())
        else:
            return max(self.children.values(), key=lambda node: node.Q() + node.U())

    def select_leaf(self):  # select leaf node
        current = self
        while current.is_expanded:
            current = current.best_child()
        return current

    def expand_leaf(self):  # expand leaf node [all]
        self.untried_actions = self.configs["paired"] if self.state.paired(
            self.action_ix) else self.configs["unpaired"]
        self.is_expanded = True
        action_ix = self.action_ix
        for action in self.untried_actions:
            new_state = self.state.copy_state()
            new_state.do_move(action, action_ix)
            self.children[action] = TreeNode(
                new_state, action_ix + 1, action, self)

    def rollout(self, simulations=None, rollouts=1, search=False,verbose=False):  # simulation phase
        current = self.state
        while self.action_ix < self.state.max_seq_len and not current.is_terminal():
            action = choice(self.configs["paired"]) if current.paired(
                self.action_ix) else choice(self.configs["unpaired"])
            current.do_move(action, self.action_ix)
            self.action_ix += 1
        assert (current.is_terminal())
        v = int(current.value() * 100)
        hamming_score = 100 - v
        mx_threshold = self.configs["mutation_threshold"]
        improve = v < 100 and hamming_score <= mx_threshold
        if verbose:print(f" value -> {v} hamming -> {hamming_score} improve -> {improve}")
        if search and improve:
            current.local_search(self.configs["max_sample"], mx_threshold)
            if verbose:print(f"Before LS {v/100} : After LS {current.value()}")
        return current.value()

    def back_up(self, result):  # backpropagation of value [ accuracy]
        self.visits += 1.
        self.total_value += result
        if self.parent:
            self.parent.back_up(result)