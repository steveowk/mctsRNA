import math
from mctsRNA.Node import TreeNode as TreeNode


class MCTS():
    def __init__(self, state, simulations, rollouts=1, search=False) -> None:
        self.state = state
        self.simulations = simulations
        self.rollouts = rollouts
        self.search = search

    def tree_search(self, action_ix, verbose=False):
        root = TreeNode(self.state, action_ix)
        for simx in range(self.simulations+1):
            leaf = root.select_leaf()
            if not leaf.is_terminal:
                leaf.expand_leaf()
            v = leaf.rollout(simx, rollouts=self.rollouts, search=self.search, verbose=verbose)  # rollout
            leaf.back_up(v)
        if verbose:
            for key, node in root.children.items():
                print(f" {key} -> {node.U()} visits {node.visits} value {node.Q()}")
        return root.best_child(infer=True).to_here


"""
# uncomment this to test MCTS

from RNAState import State as State
import yaml
from LoadRNA import LoadData as RNAData
from  MCTS import MCTS as MCTS
from random import sample
config = yaml.load(open("Configs.yml", "r"), Loader=yaml.FullLoader)
data = RNAData(**config["data"])
test = sample(data.eterna, 1)[0]
state = State(test)
mcts = MCTS(state, 500, rollouts=1, search=True)
out = mcts.search(verbose=True, action_ix=0)
print(out) """
